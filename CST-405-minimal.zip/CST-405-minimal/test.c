int x;
int y;
int z;
int r;

x = 10;
y = 20;
z = x + y;
print(z);

x = z + 5;
print(x);

r = x - 3;
print(r);

y = x + y + z;
print(y);

int a[5];
int i;
int result;

i = 0;
a[i] = 100;

i = 1;
a[i] = 200;

i = 2;
a[i] = 300;

print(a[1]);

result = a[0] + a[2];
print(result);

i = 1;
a[i + 1] = 999;
print(a[2]);